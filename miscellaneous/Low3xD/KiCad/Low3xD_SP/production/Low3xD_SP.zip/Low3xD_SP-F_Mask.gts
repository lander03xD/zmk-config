G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu22.04.1*
G04 #@! TF.CreationDate,2026-06-12T17:48:40+02:00*
G04 #@! TF.ProjectId,Low3xD_SP,4c6f7733-7844-45f5-9350-2e6b69636164,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu22.04.1) date 2026-06-12 17:48:40*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
