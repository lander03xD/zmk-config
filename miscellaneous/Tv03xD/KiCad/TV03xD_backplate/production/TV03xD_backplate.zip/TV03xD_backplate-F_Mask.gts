G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu22.04.1*
G04 #@! TF.CreationDate,2026-08-30T15:35:12+02:00*
G04 #@! TF.ProjectId,TV03xD_backplate,54563033-7844-45f6-9261-636b706c6174,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu22.04.1) date 2026-08-30 15:35:12*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H4*
X210437500Y-85562500D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X159562500Y-85562500D03*
G04 #@! TD*
G04 #@! TO.C,H5*
X210437500Y-60125000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X159562500Y-127187500D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X210437500Y-127187500D03*
G04 #@! TD*
M02*
